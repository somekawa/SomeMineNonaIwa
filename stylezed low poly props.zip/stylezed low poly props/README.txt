Old Game Stylezed Props Pack
	-24 prefabs
	-Include demo
	-256x256 Textures
	-Optimized for VR and Mobile
Enjoy!