﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SetItemCtl : MonoBehaviour
{
    public GameObject escapeItem;

    private int itemCnt = 8;
    private int pointRange;

    private List<int> setPoint = new List<int>();

    // Start is called before the first frame update
    void Start()
    {
        GameObject[] setItemPoints = this.gameObject.GetComponentsInChildren<Transform>().Select(t => t.gameObject).ToArray();
        for (int i = 0; i <= setItemPoints.Length; i++)
        {
            setPoint.Add(i);
        }

        while (itemCnt-- > 0)
        {
            pointRange = Random.Range(0, setPoint.Count);

            Instantiate(escapeItem, setItemPoints[pointRange].transform.position, setItemPoints[pointRange].transform.rotation);
            setPoint.RemoveAt(pointRange);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
