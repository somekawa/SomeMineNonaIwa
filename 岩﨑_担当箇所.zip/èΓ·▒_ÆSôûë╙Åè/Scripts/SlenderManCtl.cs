﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SlenderManCtl : MonoBehaviour
{
    // Component取得用変数
    private NavMeshAgent nav_mesh_agent;
    private Animator animator;

    public GameObject[] TargetObject;       // 移動予定地のオブジェクト
    private int TargetRange = 0;        // 移動予定地の乱数格納用
    public Vector3 SoundPoint;       // 音のした場所に向かうための座標格納用
    public bool ListenFlag;     // 音が聞こえたか否かのフラグ(デフォルト：聞こえていない＝false)

    // Start is called before the first frame update
    void Start()
    {
        animator = this.gameObject.GetComponent<Animator>();        // Animatorの取得
        nav_mesh_agent = this.gameObject.GetComponent<NavMeshAgent>();      // Nav Mesh Agentの取得
        SetTargetPoint();       // 移動先の決定
    }

    // Update is called once per frame
    void Update()
    {
        if (nav_mesh_agent.velocity.magnitude > 0)      // 移動しているかどうかの判定
        {
            animator.SetBool("moveFlag", true);     // 歩くモーションの開始
        }
        else
        {
            animator.SetBool("moveFlag", false);        // 歩くモーションの停止
            SetTargetPoint();       // 次の移動先の決定
            ListenFlag = false;     // 音のした場所に着いたらfalseにする
        }
    }

    private void SetTargetPoint()
    {
        TargetRange = Random.Range(0, TargetObject.Length);     // 決まった移動先の乱数を格納
        nav_mesh_agent.SetDestination(TargetObject[TargetRange].transform.position);        // 移動先の設定
        if (ListenFlag == true)
        {
            nav_mesh_agent.SetDestination(SoundPoint);      // 音がした場所に設定
        }
    }
}
